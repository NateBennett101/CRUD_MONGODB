"""Nate Bennett"""

import os
from pymongo import MongoClient
from bson.objectid import ObjectId

class CRUD(object):
    """ CRUD operations for MongoDB """

    def __init__(self, db_name, collection_name, user, password, host, port):
        # Initialize the MongoClient using the credentials from environment variables.
        mongo_uri = f"mongodb://{user}:{password}@{host}:{port}/{db_name}?authSource=admin&authMechanism=SCRAM-SHA-256"
        self.client = MongoClient(mongo_uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def create(self, data):
        """ This should insert a document into the specified MongoDB database and collection. """
        if data:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save because the data parameter is empty")

    def read(self, query=None):
        """ This should query for documents from the specified MongoDB database and collection. """
        if query is None:
            cursor = self.collection.find({})
        else:
            cursor = self.collection.find(query)
        result = [doc for doc in cursor]
        return result
            
    def update(self, query, update_data, is_multi=False):
        """ This should update document(s) in the specified MongoDB database and collection. """
        if query:
            if is_multi:
                result = self.collection.update_many(query, {"$set": update_data})
            else:
                result = self.collection.update_one(query, {"$set": update_data})
            
            return result.modified_count
        else:
            raise Exception("Query parameter cannot be empty")

    def delete(self, query, is_multi=False):
        """ This should delete one or more documents from the specified MongoDB database and collection. """
        if query:
            if is_multi:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            
            return result.deleted_count
        else:
            raise Exception("Query parameter cannot be empty")
